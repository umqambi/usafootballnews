<?php get_header(); ?>

<div id="content" class="clearfix">

	<h1 class="entry-title"><?php esc_html_e('404', 'rowe'); ?></h1>

	<div class="entry-content">
		<?php esc_html_e('Looks like you found a page that does not quite exist anymore, or perhaps it never did.', 'rowe'); ?>
	</div>

</div>
<!-- /#content -->

<?php get_footer(); ?>