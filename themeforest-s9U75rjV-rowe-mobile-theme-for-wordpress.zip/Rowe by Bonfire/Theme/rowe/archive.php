<?php get_header(); ?>		

<!-- BEGIN ARCHIVE -->
<?php if ( is_day() ) : ?>
	<div class="showing">
        <div class="showing-inner">
            <?php printf( get_the_date() ); ?>
        </div>
	</div>

<?php elseif ( is_month() ) : ?>
	<div class="showing">
        <div class="showing-inner">
            <?php printf( get_the_date( esc_attr_x( 'F Y', 'monthly archives format', 'rowe' ) ) ); ?>
        </div>
	</div>

<?php elseif ( is_year() ) : ?>
	<div class="showing">
        <div class="showing-inner">
            <?php printf( get_the_date( esc_attr_x( 'Y', 'yearly archives format', 'rowe' ) ) ); ?>
        </div>
	</div>

<?php else : ?>
	<?php ( 'Blog archives' ); ?>
<?php endif; ?>
<!-- END ARCHIVE -->

<div id="content" class="clearfix">
	
		<?php // the loop ?>
		<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
			
			<!-- BEGIN LOOP -->
			<?php get_template_part( 'includes/loop-index' ); ?>
			<!-- END LOOP  -->
	
		<?php endwhile; ?>
		<?php else : ?>
	
			<!-- BEGIN NO CONTENT FOUND -->
			<p><?php esc_html_e( 'Apologies, nothing found.', 'rowe' ); ?></p>
			<!-- END NO CONTENT FOUND -->
	
		<?php endif; ?>
	
		<!-- BEGIN INCLUDE PAGINATION -->
		<?php get_template_part('includes/pagination'); ?>
		<!-- END INCLUDE PAGINATION -->

</div>
<!-- END #content -->

<?php get_footer(); ?>