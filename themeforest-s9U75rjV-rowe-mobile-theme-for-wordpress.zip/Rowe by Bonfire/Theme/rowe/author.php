<?php get_header(); ?>			

<div id="content" class="clearfix">
	
		<!-- BEGIN AUTHOR NAME + DESC -->
		<div class="author-desc-wrapper">
			<div class="author-name">
				<span><?php esc_html_e( 'Posts by', 'rowe' ); ?></span> <?php printf( esc_html(get_the_author()) ); ?>
			</div>
		</div>
		<!-- END AUTHOR NAME + DESC -->	
	
		<?php // the loop ?>
		<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
			
			<!-- BEGIN LOOP -->
			<?php get_template_part( 'includes/loop-index' ); ?>
			<!-- END LOOP  -->
	
		<?php endwhile; ?>
		<?php else : ?>
	
			<!-- BEGIN NO CONTENT FOUND -->
			<p><?php esc_html_e( 'Apologies, nothing found.', 'rowe' ); ?></p>
			<!-- END NO CONTENT FOUND -->
	
		<?php endif; ?>
	
		<!-- BEGIN INCLUDE PAGINATION -->
		<?php get_template_part('includes/pagination'); ?>
		<!-- END INCLUDE PAGINATION -->

</div>
<!-- END #content -->

<?php get_footer(); ?>