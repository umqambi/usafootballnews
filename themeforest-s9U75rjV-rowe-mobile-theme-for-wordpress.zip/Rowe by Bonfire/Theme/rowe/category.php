<?php get_header(); ?>		

<div id="content" class="clearfix">

		<!-- BEGIN CATEGORY -->
		<div class="showing">
            <div class="showing-inner">
                <span><?php esc_html_e('Category:', 'rowe'); ?></span> <?php printf( '%s', '' . single_cat_title( '', false ) . '' ); ?>
            </div>
		</div>
		<!-- END CATEGORY -->

		<?php // the loop ?>
		<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
			
			<!-- BEGIN LOOP -->
			<?php get_template_part( 'includes/loop-index' ); ?>
			<!-- END LOOP  -->
	
		<?php endwhile; ?>
		<?php else : ?>
	
			<!-- BEGIN NO CONTENT FOUND -->
			<p><?php esc_html_e( 'Apologies, nothing found.', 'rowe' ); ?></p>
			<!-- END NO CONTENT FOUND -->
	
		<?php endif; ?>
	
		<!-- BEGIN INCLUDE PAGINATION -->
		<?php get_template_part('includes/pagination'); ?>
		<!-- END INCLUDE PAGINATION -->

</div>
<!-- END #content -->

<?php get_footer(); ?>