<?php if(!is_single()) : global $more; $more = 0; endif; //enable more link ?>

<div class="content-wrapper-masonry">

		<!-- BEGIN FEATURED IMAGE -->
			<div class="featured-image-masonry<?php if ( has_post_thumbnail() ) { ?><?php } else { ?> no-featured-image<?php } ?>">
				<a href="<?php echo esc_url( get_permalink() ); ?>">
					<?php the_post_thumbnail(); ?>
				</a>
			</div>
		<!-- END FEATURED IMAGE -->

		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	
			<!-- BEGIN TITLE -->
			<h1 class="entry-title-masonry">
				<!-- BEGIN IF IS STICKY -->
				<?php if (is_sticky()) { ?>
					<span class="sticky">
						<?php esc_html_e( 'Sticky:', 'rowe' ); ?>
					</span>
				<?php } ?>
				<!-- END IF IS STICKY -->
			
				<a href="<?php echo esc_url( get_permalink() ); ?>" title="<?php echo esc_attr( sprintf( esc_html__( 'Permalink to %s', 'rowe' ), the_title_attribute( 'echo=0' ) ) ); ?>" rel="bookmark">
					<?php the_title(); ?>
				</a>
			</h1>
			<!-- END TITLE -->
	
			<!-- BEGIN POST CATEGORIES -->
			<div class="post-cat">
				<?php the_category(' '); ?>
			</div>
			<!-- END POST CATEGORIES -->
	
		</article>
		
</div>
<!-- /.post -->