			<!-- BEGIN COMMENTS -->
			<?php if ( is_singular() ) { ?>
				<?php comments_template(); ?>
			<?php } ?>
			<!-- END COMMENTS -->
	
		</div>
		<!-- END body -->
	
	</div>
	<!-- END #sitewrap-inner -->

</div>
<!-- END #sitewrap -->

<!-- wp_footer -->
<?php wp_footer(); ?>
</body>
</html>