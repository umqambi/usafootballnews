<?php

///////////////////////////////////////
// You may add your custom functions here
///////////////////////////////////////

	///////////////////////////////////////
	// Add nice titles across the theme
	///////////////////////////////////////
	function rowe_wp_title( $title, $sep ) {
		global $paged, $page;
	
		if ( is_feed() )
			return $title;
	
		// Add the site name.
		$title .= get_bloginfo( 'name' );
	
		// Add the site description for the home/front page.
		$site_description = get_bloginfo( 'description', 'display' );
		if ( $site_description && ( is_home() || is_front_page() ) )
			$title = "$title $sep $site_description";
	
		// Add a page number if necessary.
		if ( $paged >= 2 || $page >= 2 )
			$title = "$title $sep " . sprintf( esc_html__( 'Page %s', 'rowe' ), max( $paged, $page ) );
	
		return $title;
	}
	add_filter( 'wp_title', 'rowe_wp_title', 10, 2 );

	///////////////////////////////////////
	// Add hook after opening body tag
	///////////////////////////////////////
	function wp_after_body() {
		do_action('wp_after_body');
	}

	///////////////////////////////////////
	// Enable featured image
	///////////////////////////////////////
	add_theme_support('post-thumbnails');

	///////////////////////////////////////
	// Add default posts and comments RSS feed links to head
	///////////////////////////////////////
	add_theme_support('automatic-feed-links');

	///////////////////////////////////////
	// Show pagination only if there's more than one page
	///////////////////////////////////////
	function show_posts_nav() {
		global $wp_query;
		return ($wp_query->max_num_pages > 1);
	}

	///////////////////////////////////////
	// Styles the visual editor with editor-style.css to match the theme style
	///////////////////////////////////////
	add_editor_style();

	///////////////////////////////////////
	// Load theme languages
	///////////////////////////////////////
	load_theme_textdomain( 'rowe', get_template_directory().'/languages' );

	///////////////////////////////////////
	// Custom Excerpt Lengths (multiple)
	///////////////////////////////////////
	function excerpt($limit) {
		$excerpt = explode(' ', get_the_excerpt(), $limit);
	if (count($excerpt)>=$limit) {
		array_pop($excerpt);
		$excerpt = implode(" ",$excerpt).' [..]';
	} else {
		$excerpt = implode(" ",$excerpt);
	}
		$excerpt = preg_replace('`[[^]]*]`','',$excerpt);
		return $excerpt;
	}

	function content($limit) {
		$content = explode(' ', get_the_content(), $limit);
	if (count($content)>=$limit) {
		array_pop($content);
		$content = implode(" ",$content).'...';
	} else {
		$content = implode(" ",$content);
	}
	$content = preg_replace('/[.+]/','', $content);
	$content = apply_filters('the_content', $content);
	$content = str_replace(']]>', ']]&gt;', $content);
	return $content;
	}
	
	///////////////////////////////////////
	// Remove [...] from excerpt
	///////////////////////////////////////
	add_filter('excerpt_more','__return_false');

	///////////////////////////////////////
	// Default Main Nav Function
	///////////////////////////////////////
	function default_main_nav() {
		echo '<ul id="main-nav" class="main-nav clearfix">';
		wp_list_pages('title_li=');
		echo '</ul>';
	}

	///////////////////////////////////////
	// Custom titles
	///////////////////////////////////////
	add_filter( 'wp_title', 'baw_hack_wp_title_for_home' );
	function baw_hack_wp_title_for_home( $title )
	{
	  if( empty( $title ) && ( is_home() || is_front_page() ) ) {
	  	echo esc_html( bloginfo('name') . ' | ' . get_bloginfo('description') );
	  }
	  return $title;
	}

	///////////////////////////////////////
	// Enqueue Google WebFonts
	///////////////////////////////////////
	function rowe_fonts_url() {
		$font_url = '';

		if ( 'off' !== _x( 'on', 'Google font: on or off', 'rowe' ) ) {
			$font_url = add_query_arg( 'family', urlencode( 'Roboto:400,500,700&subset=latin,latin-ext|Montserrat Alternates:400,700' ), "//fonts.googleapis.com/css" );
		}
		return $font_url;
	}
	function rowe_scripts() {
		wp_enqueue_style( 'rowe-fonts', rowe_fonts_url(), array(), '1.0.0' );
	}
	add_action( 'wp_enqueue_scripts', 'rowe_scripts' );

	///////////////////////////////////////
	// Enqueue style.css (default WordPress stylesheet)
	///////////////////////////////////////
	function rowe_style() {
		wp_register_style( 'style', get_stylesheet_uri() , array(), '1', 'all' );
		wp_enqueue_style( 'style' );  
	}
	add_action( 'wp_enqueue_scripts', 'rowe_style' );
	
	///////////////////////////////////////
	// Enqueue misc-footer.js
	///////////////////////////////////////
    function rowe_miscfooter() {
		wp_register_script( 'misc-footer', get_template_directory_uri() . '/js/misc-footer.js',  array( 'jquery' ), '1', true );  
		wp_enqueue_script( 'misc-footer' );
	}
	add_action( 'wp_enqueue_scripts', 'rowe_miscfooter' );

	///////////////////////////////////////
	// Enqueue autogrow/jquery.autogrow-textarea.js
	///////////////////////////////////////
    function rowe_autogrow() {
		if ( is_singular() ) {
		wp_register_script( 'autogrow', get_template_directory_uri() . '/js/autogrow/jquery.autogrow-textarea.js',  array( 'jquery' ), '1', true );  
		wp_enqueue_script( 'autogrow' );  
		}
	}
	add_action( 'wp_enqueue_scripts', 'rowe_autogrow' );

	///////////////////////////////////////
	// Enqueue comment-form.js
	///////////////////////////////////////
	function rowe_commentform() {  
		if ( is_single() ) {
		wp_register_script( 'comment-form', get_template_directory_uri() . '/js/comment-form.js',  array( 'jquery' ), '1', true );  
		wp_enqueue_script( 'comment-form' );  
		}
	}
	add_action( 'wp_enqueue_scripts', 'rowe_commentform' );

	///////////////////////////////////////
	// Enqueue jquery.scrollTo-min.js (smooth scrolling to anchors)
	///////////////////////////////////////
    function rowe_scrollto() {  
		wp_register_script( 'scroll-to', get_template_directory_uri() . '/js/jquery.scrollTo-min.js',  array( 'jquery' ), '1', true );  
		wp_enqueue_script( 'scroll-to' );  
	}
	add_action( 'wp_enqueue_scripts', 'rowe_scrollto' ); 

	///////////////////////////////////////
	// Enqueue comment-reply.js (threaded comments)
	///////////////////////////////////////
	function rowe_comment_reply(){
		if ( is_singular() && get_option( 'thread_comments' ) )	wp_enqueue_script( 'comment-reply' );
	}
	add_action('wp_print_scripts', 'rowe_comment_reply');
	
	///////////////////////////////////////
	// Define content width
	///////////////////////////////////////
	if ( ! isset( $content_width ) ) $content_width = 1000;

	///////////////////////////////////////
	// Custom Comment Output
	///////////////////////////////////////
	function custom_theme_comment($comment, $args, $depth) {
	   $GLOBALS['comment'] = $comment; 
	   ?>

		<li id="comment-<?php comment_ID() ?>" <?php comment_class(); ?>>

			<span class="comment-author"><?php printf(get_comment_author_link()) ?></span>
			<span class="comment-time"><?php esc_html_e( 'commented on', 'rowe' ); ?> <?php comment_date('F j'); ?></span>

			<div class="comment-entry">
				<?php echo wp_kses_post(get_comment_text()); ?>
				<?php if ($comment->comment_approved == '0') : ?>
					<span class="awaiting-moderation"><?php esc_html_e('(Awaiting moderation.)', 'rowe') ?></span>
				<?php endif; ?>

				<?php comment_reply_link(array_merge( $args, array('add_below' => 'comment', 'depth' => $depth, 'reply_text' => esc_html__( 'Reply', 'rowe' ), 'max_depth' => $args['max_depth']))) ?>
				<?php edit_comment_link( esc_html__('Edit', 'rowe')) ?>
			</div>
		
	<?php
	}

?>