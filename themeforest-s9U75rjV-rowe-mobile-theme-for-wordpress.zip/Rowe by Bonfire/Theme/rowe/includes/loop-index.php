<?php if(!is_single()) : global $more; $more = 0; endif; //enable more link ?>

<div class="wrapper-outer-index">
	
	<div class="content-wrapper">

        <!-- BEGIN DATE -->
        <div class="post-date">
            <a href="<?php echo esc_url( get_permalink() ); ?>">
                <?php echo esc_attr(the_time(get_option('date_format'))); ?>
            </a>
        </div>
        <!-- END DATE -->
    
		<!-- BEGIN FEATURED IMAGE (+ caption if one exists) -->
		<?php if( get_post_meta($post->ID, 'Shortcode', true) || get_post_meta($post->ID, 'FeaturedEmbed', true) ) { ?>
		<?php } else { ?>
			<?php if ( has_post_thumbnail() ) { ?>
				<div class="featured-image">
					<!-- BEGIN FEATURED IMAGE -->
					<a href="<?php echo esc_url( get_permalink() ); ?>">
						<?php the_post_thumbnail(); ?>
					</a>
					<!-- END FEATURED IMAGE -->
		
					<!-- BEGIN FEATURED IMAGE CAPTION -->
					<?php $get_description = get_post(get_post_thumbnail_id())->post_excerpt; if(!empty($get_description)){	echo '<div class="featured-image-caption">' . wp_kses_post( get_post(get_post_thumbnail_id())->post_excerpt ) . '</div>'; } ?>
					<!-- END FEATURED IMAGE CAPTION -->
				</div>
			<?php } ?>
		<?php } ?>
		<!-- END FEATURED IMAGE (+ caption if one exists) -->

		<!-- BEGIN CUSTOM FIELD FOR EMBEDDABLE CONTENT -->
		<?php $featuredembed = get_post_meta($post->ID, 'FeaturedEmbed', true); ?>
		<div class="featuredembed-container"><?php echo $featuredembed; ?></div>
		<!-- END CUSTOM FIELD FOR EMBEDDABLE CONTENT -->

		<!-- BEGIN SHORTCODE OUTSIDE THE LOOP -->
		<div class="shortcode-wrapper">
			<?php $shortcode = get_post_meta($post->ID, 'Shortcode', true); ?><?php echo do_shortcode($shortcode); ?>
		</div>
		<!-- END SHORTCODE OUTSIDE THE LOOP -->

		<!-- BEGIN CONTENT -->
            <!-- BEGIN POST AUTHOR -->
			<div class="post-author">
				<?php esc_html_e( 'By ', 'rowe' ); ?><a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" rel="author"><?php printf( esc_html(get_the_author()) ); ?></a>
			</div>
			<!-- END POST AUTHOR -->

			<!-- BEGIN TITLE -->
			<div class="entry-title<?php if ( has_post_thumbnail() || get_post_meta($post->ID, 'Shortcode', true) || get_post_meta($post->ID, 'FeaturedEmbed', true) ) { ?><?php } else { ?> entry-title-no-feat-img<?php } ?>">
				<!-- BEGIN IF IS STICKY -->
				<?php if (is_sticky()) { ?>
					<span class="sticky">
						<?php esc_html_e( 'Featured:', 'rowe' ); ?>
					</span>
				<?php } ?>
				<!-- END IF IS STICKY -->
				<a href="<?php echo esc_url( get_permalink() ); ?>" title="<?php echo esc_attr( sprintf( esc_html__( 'Permalink to %s', 'rowe' ), the_title_attribute( 'echo=0' ) ) ); ?>" rel="bookmark">
					<h1><?php the_title(); ?></h1>
				</a>
			</div>
			<!-- END TITLE -->
			
			<!-- BEGIN EDIT LINK -->
			<?php edit_post_link(esc_html__('Edit post', 'rowe')); ?>
			<!-- END EDIT LINK -->

			<!-- BEGIN CONTENT -->
			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
				<div class="entry-content">
					
					<!-- BEGIN CONTENT -->
					<p><?php echo excerpt(50); ?></p>
					<!-- END CONTENT -->

					<!-- BEGIN POST NAVIGATION -->
					<div class="link-pages">
						<?php wp_link_pages(array(''.esc_html__('Pages:', 'rowe').' ', 'next_or_number' => 'number')); ?>
					</div>
					<!-- END POST NAVIGATION -->

					<!-- BEGIN PERMALINK BUTTON -->
                    <a href="<?php echo esc_url( get_permalink() ); ?>">
                        <div class="story-permalink">
                            <div class="story-permalink-inner"></div>
                        </div>
                    </a>
					<!-- END PERMALINK BUTTON -->
				</div>
			</article>
			<!-- END CONTENT -->
		<!-- END CONTENT -->
	
	</div>
	<!-- /.content-wrapper -->

</div>
<!-- /.wrapper.outer -->