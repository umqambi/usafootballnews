<?php if(!is_single()) : global $more; $more = 0; endif; //enable more link ?>

<div class="wrapper-outer">
	
	<div class="content-wrapper">
        
        <!-- BEGIN DATE -->
        <div class="post-date">
            <a href="<?php echo esc_url( get_permalink() ); ?>">
                <?php echo esc_attr(the_time(get_option('date_format'))); ?>
            </a>
        </div>
        <!-- END DATE -->

		<!-- BEGIN FEATURED IMAGE (+ caption if one exists) -->
		<?php if( get_post_meta($post->ID, 'Shortcode', true) || get_post_meta($post->ID, 'FeaturedEmbed', true) ) { ?>
		<?php } else { ?>
			<?php if ( has_post_thumbnail() ) { ?>
				<div class="featured-image">
					<!-- BEGIN FEATURED IMAGE -->
					<a href="<?php echo esc_url( get_permalink() ); ?>">
						<?php the_post_thumbnail(); ?>
					</a>
					<!-- END FEATURED IMAGE -->
		
					<!-- BEGIN FEATURED IMAGE CAPTION -->
					<?php $get_description = get_post(get_post_thumbnail_id())->post_excerpt; if(!empty($get_description)){	echo '<div class="featured-image-caption">' . wp_kses_post( get_post(get_post_thumbnail_id())->post_excerpt ) . '</div>'; } ?>
					<!-- END FEATURED IMAGE CAPTION -->
				</div>
			<?php } ?>
		<?php } ?>
		<!-- END FEATURED IMAGE (+ caption if one exists) -->
		
		<!-- BEGIN CUSTOM FIELD FOR EMBEDDABLE CONTENT -->
		<?php $featuredembed = get_post_meta($post->ID, 'FeaturedEmbed', true); ?>
		<div class="featuredembed-container"><?php echo $featuredembed; ?></div>
		<!-- END CUSTOM FIELD FOR EMBEDDABLE CONTENT -->
		
		<!-- BEGIN SHORTCODE OUTSIDE THE LOOP -->
		<div class="shortcode-wrapper">
			<?php $shortcode = get_post_meta($post->ID, 'Shortcode', true); ?><?php echo do_shortcode($shortcode); ?>
		</div>
		<!-- END SHORTCODE OUTSIDE THE LOOP -->

		<!-- BEGIN CONTENT -->
            <!-- BEGIN POST AUTHOR -->
			<div class="post-author">
				<?php esc_html_e( 'By ', 'rowe' ); ?><a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" rel="author"><?php printf( esc_html(get_the_author()) ); ?></a>
			</div>
			<!-- END POST AUTHOR -->
                    
			<!-- BEGIN TITLE -->
			<div class="entry-title<?php if ( has_post_thumbnail() || get_post_meta($post->ID, 'Shortcode', true) || get_post_meta($post->ID, 'FeaturedEmbed', true) ) { ?><?php } else { ?> entry-title-no-feat-img<?php } ?>">
				<a href="<?php echo esc_url( get_permalink() ); ?>" title="<?php echo esc_attr( sprintf( esc_html__( 'Permalink to %s', 'rowe' ), the_title_attribute( 'echo=0' ) ) ); ?>" rel="bookmark">
					<h1><?php the_title(); ?></h1>
				</a>
			</div>
			<!-- END TITLE -->
			
			<!-- BEGIN EDIT LINK -->
			<?php edit_post_link(esc_html__('Edit post', 'rowe')); ?>
			<!-- END EDIT LINK -->
	
			<!-- BEGIN CONTENT + AUTHOR -->
			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
				<div class="entry-content">

					<!-- BEGIN CONTENT -->
					<?php the_content( esc_html__( 'Continues..', 'rowe' ) ); ?>
					<!-- END CONTENT -->

					<!-- BEGIN POST NAVIGATION -->
					<div class="link-pages">
						<?php wp_link_pages(array(''.esc_html__('Pages:', 'rowe').' ', 'next_or_number' => 'number')); ?>
					</div>
					<!-- END POST NAVIGATION -->
				</div>
			</article>
			<!-- END CONTENT + AUTHOR -->
			
			<!-- BEGIN POST CAT + TAGS -->
			<div class="post-cat-tag<?php if ( has_post_thumbnail() || get_post_meta($post->ID, 'Shortcode', true) || get_post_meta($post->ID, 'FeaturedEmbed', true) ) { ?><?php } else { ?> post-cat-tag-hide<?php } ?>">
				<!-- BEGIN POST CAT -->
				<span class="post-cat">
                    <?php esc_html_e( 'Filed under:', 'rowe' ); ?>
					<?php the_category(' '); ?>
				</span>
				<!-- END POST CAT -->

				<!-- BEGIN POST TAGS -->
				<span class="post-tag">
                    <?php esc_html_e( 'Tags:', 'rowe' ); ?>
					<?php the_tags('',' ',''); ?>
				</span>
				<!-- END POST TAGS -->
			</div>
			<!-- END POST CAT + TAGS -->
		<!-- END CONTENT -->
	
	</div>
	<!-- /.content-wrapper -->

</div>
<!-- /.wrapper.outer -->

<!-- BEGIN PREV/HOME/NEXT POST BUTTONS -->
<div class="prev-home-next-wrapper">
	<!-- BEGIN PREV POST BUTTON -->
	<a class="prev-post" href="<?php echo esc_url(get_permalink(get_adjacent_post(false,'',true))); ?>">
		<?php esc_html_e( 'Previous', 'rowe' ); ?></a>
	<!-- END PREV POST BUTTON -->

	<!-- BEGIN HOME BUTTON -->
	<a class="home-link" href="<?php echo esc_url( home_url( '/' ) ); ?>">
		<?php esc_html_e( 'Home', 'rowe' ); ?></a>
	<!-- END HOME BUTTON -->

	<!-- BEGIN NEXT POST BUTTON -->
	<a class="next-post" href="<?php echo esc_url(get_permalink(get_adjacent_post(false,'',false))); ?>">
		<?php esc_html_e( 'Next', 'rowe' ); ?>
	</a>
	<!-- END NEXT POST BUTTON -->
</div>
<!-- END PREV/HOME/NEXT POST BUTTONS -->