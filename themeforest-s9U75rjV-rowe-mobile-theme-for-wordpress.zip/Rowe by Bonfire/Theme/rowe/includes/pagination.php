<?php if ( is_singular() ) { ?>
<?php } else { ?>
<div class="clear"></div>
<!-- BEGIN NEXT PAGE, PREV PAGE -->						
<div class="post-nav">
    <div class="nav-label">
        <?php esc_html_e( 'Prev', 'rowe' ); ?><span>|</span><?php esc_html_e( 'Next', 'rowe' ); ?>
    </div>
    <div class="prev-inactive"><?php previous_posts_link('<div class="prev"></div>'); ?></div>
    <div class="next-inactive"><?php next_posts_link('<div class="next"></div>'); ?></div>
</div>
<!-- END NEXT PAGE, PREV PAGE -->
<?php } ?>