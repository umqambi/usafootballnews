jQuery('.comment-count').on('touchstart click', function(e) {
	'use strict';
		e.preventDefault();
			jQuery(window).scrollTo( '#comments', 800, {offset:-110} );
});
/* when comment textarea is clicked */
jQuery('#comment').click(function() {
	'use strict';
});
/* when 'reply' link is clicked */
jQuery('.comment-reply-link').click(function() {
	'use strict';
		jQuery('#cancel-comment-reply-link').show(0);
});
/* when comment reply is cancelled */
jQuery('#cancel-comment-reply-link').click(function() {
	'use strict';
		jQuery('#cancel-comment-reply-link').hide(0);
});