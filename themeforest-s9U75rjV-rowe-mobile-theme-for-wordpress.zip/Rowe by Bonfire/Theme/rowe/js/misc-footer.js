<!-- BEGIN SEARCH -->
jQuery('.search-button').on('touchstart click', function(e) {
'use strict';
	e.preventDefault();
		if(jQuery('.search-button').hasClass('search-button-active'))
		{
			/* de-activate search button */
			jQuery('.search-button').removeClass('search-button-active');
			/* de-activate search field */
			jQuery('.search-wrapper').removeClass('search-wrapper-active');
			/* de-focus search field */
			jQuery('.search-wrapper #searchform #s').blur();
			/* slide content to the left */
			jQuery('#sitewrap-inner, .logo-wrapper, .search-button').removeClass('sitewrap-search-active');
		} else {
			/* activate search button */
			jQuery('.search-button').addClass('search-button-active');
			/* activate search field */
			jQuery('.search-wrapper').addClass('search-wrapper-active');
			/* focus search field */
			jQuery('.search-wrapper #searchform #s').focus();
			/* slide content to the right */
			jQuery('#sitewrap-inner, .logo-wrapper, .search-button').addClass('sitewrap-search-active');
		}
});
<!-- END SEARCH -->

<!-- BEGIN USER MENU -->
jQuery('.user-menu-wrapper .logo .open-menu').on('touchstart click', function(e) {
'use strict';
	e.preventDefault();
		if(jQuery('.user-menu-wrapper').hasClass('user-menu-wrapper-active'))
		{
			/* de-activate search button */
			jQuery('.user-menu-wrapper').removeClass('user-menu-wrapper-active');
			
		} else {
			/* activate search button */
			jQuery('.user-menu-wrapper').addClass('user-menu-wrapper-active');
		}
});
<!-- END USER MENU -->

<!-- BEGIN CAT/TAG TOOLTIP -->
var tooltip = document.querySelectorAll('.post-cat .tooltip, .post-tag .tooltip');
document.addEventListener('mousemove', fn, false);
function fn(e) {
    for (var i=tooltip.length; i--;) {
        tooltip[i].style.left = e.pageX + 'px';
        tooltip[i].style.top = e.pageY + 'px';
    }
}
<!-- END CAT/TAG TOOLTIP -->