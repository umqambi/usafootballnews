<?php get_header(); ?>

<div class="wrapper-outer">

	<div class="content-wrapper">
        
        <!-- BEGIN DATE -->
        <div class="post-date">
            <a href="<?php echo esc_url( get_permalink() ); ?>">
                <?php echo esc_attr(the_time(get_option('date_format'))); ?>
            </a>
        </div>
        <!-- END DATE -->

		<!-- BEGIN FEATURED IMAGE (+ caption if one exists) -->
		<?php if ( has_post_thumbnail() ) { ?>
			<div class="featured-image">
				<!-- BEGIN FEATURED IMAGE -->
				<a href="<?php echo esc_url( get_permalink() ); ?>">
					<?php the_post_thumbnail(); ?>
				</a>
				<!-- END FEATURED IMAGE -->
	
				<!-- BEGIN FEATURED IMAGE CAPTION -->
				<?php $get_description = get_post(get_post_thumbnail_id())->post_excerpt; if(!empty($get_description)){	echo '<div class="featured-image-caption">' . wp_kses_post( get_post(get_post_thumbnail_id())->post_excerpt ) . '</div>'; } ?>
				<!-- END FEATURED IMAGE CAPTION -->
			</div>
		<?php } ?>
		<!-- END FEATURED IMAGE (+ caption if one exists) -->
		
		<!-- BEGIN SHORTCODE OUTSIDE THE LOOP -->
		<div class="shortcode-wrapper">
			<?php $shortcode = get_post_meta($post->ID, 'Shortcode', true); ?><?php echo do_shortcode($shortcode); ?>
		</div>
		<!-- END SHORTCODE OUTSIDE THE LOOP -->

		<!-- BEGIN CONTENT -->
		<?php while ( have_posts() ) : the_post(); ?>
			<!-- BEGIN TITLE -->
			<div class="entry-title<?php if ( has_post_thumbnail() || get_post_meta($post->ID, 'Shortcode', true) ) { ?><?php } else { ?> entry-title-no-feat-img<?php } ?>">
				<a href="<?php echo esc_url( get_permalink() ); ?>" title="<?php echo esc_attr( sprintf( esc_html__( 'Permalink to %s', 'rowe' ), the_title_attribute( 'echo=0' ) ) ); ?>" rel="bookmark">
					<h1><?php the_title(); ?></h1>
				</a>
			</div>
			<!-- END TITLE -->
			
			<!-- BEGIN EDIT LINK -->
			<?php edit_post_link(esc_html__('Edit page', 'rowe')); ?>
			<!-- END EDIT LINK -->
	
			<!-- BEGIN CONTENT + AUTHOR -->
			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
				<div class="entry-content">

					<!-- BEGIN CONTENT -->
					<?php the_content(); ?>
					<!-- END CONTENT -->

					<!-- BEGIN POST NAVIGATION -->
					<div class="link-pages">
						<?php wp_link_pages(array(''.esc_html__('Pages:', 'rowe').' ', 'next_or_number' => 'number')); ?>
					</div>
					<!-- END POST NAVIGATION -->

				</div>
			</article>
			<!-- END CONTENT + AUTHOR -->
		<?php endwhile; ?>
		<!-- END CONTENT -->
	
	</div>
	<!-- /.content-wrapper -->

</div>
<!-- /.wrapper.outer -->

<?php get_footer(); ?>