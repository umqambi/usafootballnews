<?php get_header(); ?>		

<div id="content" class="clearfix">

		<!-- BEGIN SEARCH RESULTS -->
		<div class="showing">
            <div class="showing-inner">
                <span><?php esc_html_e( 'Results for:', 'rowe' ); ?></span> <?php printf( '' . get_search_query() . '' ); ?>
            </div>
		</div>
		<!-- END SEARCH RESULTS -->

		<?php // the loop ?>
		<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
			
			<!-- BEGIN LOOP -->
			<?php get_template_part( 'includes/loop-index' ); ?>
			<!-- END LOOP  -->
	
		<?php endwhile; ?>
		<?php else : ?>
	
			<!-- BEGIN NO CONTENT FOUND -->
			<div class="wrapper-outer">
                <div class="no-search-results">
                    <?php esc_html_e( 'Apologies, nothing found.', 'rowe' ); ?>
                </div>
			</div>
			<!-- END NO CONTENT FOUND -->
	
		<?php endif; ?>
	
		<!-- BEGIN INCLUDE PAGINATION -->
		<?php get_template_part('includes/pagination'); ?>
		<!-- END INCLUDE PAGINATION -->

</div>
<!-- END #content -->

<?php get_footer(); ?>