<!-- BEGIN SEARCH FORM -->
<div class="searchform-wrapper">
	<form method="get" id="searchform" action="<?php echo esc_url( home_url() ); ?>/">
		<input type="text" name="s" id="s" placeholder="<?php esc_html_e( 'type and press enter to search ' , 'rowe' ) ?>">
	</form>
</div>
<!-- END SEARCH FORM -->